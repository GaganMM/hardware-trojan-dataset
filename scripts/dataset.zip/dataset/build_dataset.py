from pathlib import Path
import hashlib
import json
import re

import pandas as pd
import yaml


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

INVENTORY = ROOT / "metadata" / "rtl_inventory.csv"
MANIFEST = ROOT / "metadata" / "manifest.csv"
DUPLICATES = ROOT / "metadata" / "duplicate_report.csv"
STATS = ROOT / "metadata" / "dataset_stats.json"
KNOWLEDGE_BASE = ROOT / "knowledge" / "benchmark_db.yaml"
DOWNLOADS = ROOT / "downloads"

MANIFEST.parent.mkdir(parents=True, exist_ok=True)


# ============================================================
# FILTER RULES
# ============================================================

BAD_FILE_PATTERNS = [
    r"(^|[_\-.])tb([_\-.]|$)",
    r"testbench",
    r"(^|[_\-.])test([_\-.]|$)",
    r"stimulus",
    r"scoreboard",
    r"uvm",
]

BAD_PATH_PARTS = {
    "test",
    "tests",
    "testbench",
    "testbenches",
    "verification",
    "verif",
    "uvm",
    "simulation",
    "sim",
    "formal",
    "coverage",
    "generated",
    "build",
    "obj",
    "cache",
}


# ============================================================
# FAMILY RULES
# ============================================================

FAMILY_RULES = [
    ("picorv32", "RISCV"),
    ("riscv", "RISCV"),
    ("ibex", "RISCV"),
    ("serv", "RISCV"),
    ("aes", "AES"),
    ("sha", "SHA"),
    ("rsa", "RSA"),
    ("des", "DES"),
    ("rs232", "UART"),
    ("uart", "UART"),
    ("ethernet", "Ethernet"),
    ("i2c", "I2C"),
    ("spi", "SPI"),
    ("can", "CAN"),
    ("cpu", "CPU"),
]


APPLICATION_RULES = {
    "AES": "Cryptography",
    "DES": "Cryptography",
    "SHA": "Cryptography",
    "RSA": "Cryptography",

    "UART": "Communication",
    "SPI": "Communication",
    "I2C": "Communication",
    "CAN": "Communication",
    "Ethernet": "Communication",

    "CPU": "Processor",
    "RISCV": "Processor",
}


# ============================================================
# HELPERS
# ============================================================

def normalize(value):
    if pd.isna(value):
        return ""
    return str(value).strip()


def locate_file(row):

    repository = normalize(row.get("repository"))

    relative_path = normalize(
        row.get(
            "relative_path",
            row.get("file_path", "")
        )
    )

    if not repository or not relative_path:
        return None

    return DOWNLOADS / repository / Path(relative_path)


def should_remove(row):

    filename = normalize(
        row.get(
            "file_name",
            Path(normalize(row.get("relative_path"))).name
        )
    ).lower()

    relative_path = normalize(
        row.get(
            "relative_path",
            row.get("file_path", "")
        )
    ).lower()

    for pattern in BAD_FILE_PATTERNS:
        if re.search(pattern, filename):
            return True, "Test/verification filename"

    path_parts = {
        part.lower()
        for part in Path(relative_path).parts
    }

    if path_parts.intersection(BAD_PATH_PARTS):
        return True, "Test/simulation/generated path"

    return False, ""


def sha256_file(path):

    digest = hashlib.sha256()

    with path.open("rb") as f:

        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b""
        ):
            digest.update(chunk)

    return digest.hexdigest()


def count_loc(path):

    try:
        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )
    except Exception:
        return 0

    count = 0
    inside_block_comment = False

    for line in text.splitlines():

        line = line.strip()

        if not line:
            continue

        # Handle /* ... */ comments approximately
        if inside_block_comment:

            if "*/" in line:
                line = line.split("*/", 1)[1].strip()
                inside_block_comment = False

            else:
                continue

        while "/*" in line:

            before, after = line.split("/*", 1)

            if "*/" in after:

                after = after.split("*/", 1)[1]

                line = (
                    before.strip()
                    + " "
                    + after.strip()
                ).strip()

            else:

                line = before.strip()
                inside_block_comment = True
                break

        if not line:
            continue

        if line.startswith("//"):
            continue

        # Strip trailing // comments
        line = line.split("//", 1)[0].strip()

        if line:
            count += 1

    return count


def infer_family(row):

    text = " ".join([
        normalize(row.get("repository")),
        normalize(row.get("file_name")),
        normalize(row.get("module")),
        normalize(row.get("relative_path")),
    ]).lower()

    for keyword, family in FAMILY_RULES:

        if keyword in text:
            return family

    return "Unknown"


def infer_application(family):

    return APPLICATION_RULES.get(
        family,
        "Unknown"
    )


# ============================================================
# KNOWLEDGE BASE
# ============================================================

def load_knowledge_base():

    if not KNOWLEDGE_BASE.exists():
        print(
            "[WARNING] benchmark_db.yaml not found. "
            "Knowledge-based labels will remain Unknown."
        )

        return {}

    with KNOWLEDGE_BASE.open(
        "r",
        encoding="utf-8"
    ) as f:

        return yaml.safe_load(f) or {}


KNOWLEDGE = load_knowledge_base()


def find_kb_label(repository):

    repo_lower = repository.lower()

    # Generic, explicit repository mappings.
    mappings = KNOWLEDGE.get(
        "repository_mappings",
        []
    )

    for mapping in mappings:

        pattern = normalize(
            mapping.get("pattern")
        ).lower()

        if not pattern:
            continue

        match_type = normalize(
            mapping.get("match", "contains")
        ).lower()

        matched = False

        if match_type == "exact":
            matched = repo_lower == pattern

        elif match_type == "startswith":
            matched = repo_lower.startswith(pattern)

        elif match_type == "regex":

            try:
                matched = bool(
                    re.search(
                        pattern,
                        repository,
                        re.IGNORECASE
                    )
                )
            except re.error:
                matched = False

        else:
            matched = pattern in repo_lower

        if matched:

            return {
                "source":
                    normalize(
                        mapping.get(
                            "source",
                            "Unknown"
                        )
                    ),

                "family":
                    normalize(
                        mapping.get(
                            "family",
                            "Unknown"
                        )
                    ),

                "application":
                    normalize(
                        mapping.get(
                            "application",
                            "Unknown"
                        )
                    ),

                "binary_label":
                    normalize(
                        mapping.get(
                            "binary_label",
                            "Unknown"
                        )
                    ),

                "trojan_type":
                    normalize(
                        mapping.get(
                            "trojan_type",
                            "Unknown"
                        )
                    ),

                "trigger_type":
                    normalize(
                        mapping.get(
                            "trigger_type",
                            "Unknown"
                        )
                    ),

                "payload_type":
                    normalize(
                        mapping.get(
                            "payload_type",
                            "Unknown"
                        )
                    ),

                "confidence":
                    normalize(
                        mapping.get(
                            "confidence",
                            "High"
                        )
                    ),
            }

    return None


# ============================================================
# LOAD INVENTORY
# ============================================================

print("=" * 70)
print("HTBench Dataset Builder")
print("=" * 70)

if not INVENTORY.exists():

    raise FileNotFoundError(
        f"Missing inventory:\n{INVENTORY}"
    )

for repo in downloads:
    for *.v and *.sv:
        add to inventory
print(inventory.columns.tolist())
print(inventory.head())

print(f"Inventory files : {len(inventory)}")


# ============================================================
# BUILD DATASET
# ============================================================

records = []
rejected = []

missing_files = 0


for _, row in inventory.iterrows():
    if _ < 5:
    	print(row.to_dict())
    remove, reason = should_remove(row)

    if remove:

        rejected.append({
            "repository":
                normalize(row.get("repository")),

            "file":
                normalize(row.get("file_name")),

            "reason":
                reason
        })

        continue

    file_path = locate_file(row)
    if _ < 5:
    	print("Expected path:", file_path)
    	print("Exists:", file_path.exists() if file_path else None)
    if file_path is None or not file_path.exists():

        missing_files += 1
        continue

    # Ignore tiny/empty files
    if file_path.stat().st_size < 100:

        rejected.append({
            "repository":
                normalize(row.get("repository")),

            "file":
                file_path.name,

            "reason":
                "File smaller than 100 bytes"
        })

        continue

    repository = normalize(
        row.get("repository")
    )

    module_name = normalize(
        row.get(
            "module",
            file_path.stem
        )
    )

    family = infer_family(row)
    application = infer_application(family)

    source = "GitHub"

    binary_label = "Unknown"
    trojan_type = "Unknown"
    trigger_type = "Unknown"
    payload_type = "Unknown"

    confidence = "Low"

    kb = find_kb_label(repository)

    if kb:

        source = kb["source"]

        if kb["family"] != "Unknown":
            family = kb["family"]

        if kb["application"] != "Unknown":
            application = kb["application"]

        binary_label = kb["binary_label"]
        trojan_type = kb["trojan_type"]
        trigger_type = kb["trigger_type"]
        payload_type = kb["payload_type"]

        confidence = kb["confidence"]

    elif family != "Unknown":

        confidence = "Medium"

    language = (
        "SystemVerilog"
        if file_path.suffix.lower() == ".sv"
        else "Verilog"
    )

    relative_path = normalize(
        row.get(
            "relative_path",
            row.get("file_path", "")
        )
    )

    records.append({

        "module_name":
            module_name,

        "repository":
            repository,

        "source":
            source,

        "file_name":
            file_path.name,

        "relative_path":
            relative_path,

        "sha256":
            sha256_file(file_path),

        "language":
            language,

        "family":
            family,

        "application":
            application,

        "loc":
            count_loc(file_path),

        "file_size_kb":
            round(
                file_path.stat().st_size / 1024,
                2
            ),

        "binary_label":
            binary_label,

        "trojan_type":
            trojan_type,

        "trigger_type":
            trigger_type,

        "payload_type":
            payload_type,

        "confidence":
            confidence,

        "status":
            "Review Needed",

        "reviewer":
            "",

        "remarks":
            "",
    })


manifest = pd.DataFrame(records)

if manifest.empty:

    raise RuntimeError(
        "No usable RTL files survived dataset construction."
    )


# ============================================================
# DUPLICATE DETECTION
# ============================================================

duplicate_mask = manifest.duplicated(
    subset=["sha256"],
    keep="first"
)

duplicate_report = manifest[
    duplicate_mask
].copy()

duplicate_report["duplicate_reason"] = (
    "Identical SHA256"
)

duplicate_report.to_csv(
    DUPLICATES,
    index=False
)

manifest = manifest[
    ~duplicate_mask
].copy()


# ============================================================
# STABLE ORDER + IDs
# ============================================================

manifest = manifest.sort_values(
    by=[
        "repository",
        "relative_path"
    ]
).reset_index(drop=True)

manifest.insert(
    0,
    "rtl_id",
    [
        f"RTL{i:06d}"
        for i in range(
            1,
            len(manifest) + 1
        )
    ]
)


# ============================================================
# REVIEW STATUS
# ============================================================

high_confidence = (
    (manifest["confidence"] == "High")
    &
    (manifest["binary_label"] != "Unknown")
)

manifest.loc[
    high_confidence,
    "status"
] = "Auto-Labeled"


# ============================================================
# SAVE MANIFEST
# ============================================================

manifest.to_csv(
    MANIFEST,
    index=False
)


# ============================================================
# STATISTICS
# ============================================================

stats = {

    "inventory_files":
        int(len(inventory)),

    "accepted_unique_files":
        int(len(manifest)),

    "rejected_files":
        int(len(rejected)),

    "duplicate_files":
        int(len(duplicate_report)),

    "missing_files":
        int(missing_files),

    "clean":
        int(
            (
                manifest["binary_label"]
                == "Clean"
            ).sum()
        ),

    "trojan":
        int(
            (
                manifest["binary_label"]
                == "Trojan"
            ).sum()
        ),

    "unknown":
        int(
            (
                manifest["binary_label"]
                == "Unknown"
            ).sum()
        ),

    "high_confidence":
        int(
            (
                manifest["confidence"]
                == "High"
            ).sum()
        ),

    "medium_confidence":
        int(
            (
                manifest["confidence"]
                == "Medium"
            ).sum()
        ),

    "low_confidence":
        int(
            (
                manifest["confidence"]
                == "Low"
            ).sum()
        )
}


with STATS.open(
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        stats,
        f,
        indent=4
    )


# ============================================================
# SUMMARY
# ============================================================

print()
print("=" * 70)
print("Dataset Build Complete")
print("=" * 70)

print(
    f"Inventory        : "
    f"{stats['inventory_files']}"
)

print(
    f"Accepted         : "
    f"{stats['accepted_unique_files']}"
)

print(
    f"Rejected         : "
    f"{stats['rejected_files']}"
)

print(
    f"Duplicates       : "
    f"{stats['duplicate_files']}"
)

print(
    f"Missing files    : "
    f"{stats['missing_files']}"
)

print()

print(
    f"Clean            : "
    f"{stats['clean']}"
)

print(
    f"Trojan           : "
    f"{stats['trojan']}"
)

print(
    f"Unknown          : "
    f"{stats['unknown']}"
)

print()

print(
    f"High confidence  : "
    f"{stats['high_confidence']}"
)

print(
    f"Medium confidence: "
    f"{stats['medium_confidence']}"
)

print(
    f"Low confidence   : "
    f"{stats['low_confidence']}"
)

print()

print(f"Manifest   : {MANIFEST}")
print(f"Duplicates : {DUPLICATES}")
print(f"Statistics : {STATS}")